<?php
/**
 * Template Name: Página Legal - Termos e Condições
 * Description: Página institucional oficial de Termos e Condições de Uso e Compra da obra O Pacto de 1 Bilhão.
 */

if (!defined('ABSPATH')) {
    exit;
}

$template_uri = get_stylesheet_directory_uri();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5">
  <meta name="theme-color" content="#071520">
  <title>Termos e Condições — O Pacto de 1 Bilhão | Salih Abdulatif</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,700&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="<?php echo esc_url($template_uri . '/style.css?v=8.1'); ?>">
  <?php wp_head(); ?>
</head>
<body class="legal-page" id="topo">

  <header class="legal-header">
    <div class="shell-container legal-header__inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__brand" aria-label="O Pacto de 1 Bilhão - Início">
        <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="legal-header__logo" width="135" height="58" loading="eager">
      </a>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__back">
        <span>←</span> Voltar ao início
      </a>
    </div>
  </header>

  <section class="legal-hero">
    <div class="shell-container">
      <span class="section-index">DOCUMENTO OFICIAL • CONTRATO DE AQUISIÇÃO</span>
      <h1>Termos e <em>Condições</em></h1>
      <p>Termos gerais de navegação, aquisição comercial e diretrizes legais de proteção autoral da obra oficial de Salih Abdulatif.</p>
    </div>
  </section>

  <main class="legal-main">
    <div class="shell-container">
      <article class="legal-card">
        
        <div class="legal-highlight-box">
          <strong>Aviso Legal Fundamental:</strong> O livro "O Pacto de 1 Bilhão" relata a trajetória pessoal, experiências empresariais reais, sucessos e falências vivenciados por Salih Abdulatif. A obra possui caráter estritamente reflexivo, biográfico e educativo, <strong>não configurando promessa, garantia ou indução a ganhos financeiros ou resultados econômicos imediatos.</strong>
        </div>

        <h2><span class="num">01.</span> Aceitação e Abrangência dos Termos</h2>
        <p>Ao acessar este site e efetuar a compra de qualquer edição do livro <strong>"O Pacto de 1 Bilhão"</strong>, você declara ter lido, compreendido e concordado integralmente com estes Termos e Condições, submetendo-se às leis da República Federativa do Brasil.</p>

        <h2><span class="num">02.</span> Natureza da Obra e Responsabilidade Editorial</h2>
        <p>A obra tem como objetivo proporcionar uma imersão nos bastidores dos negócios, tomada de decisão sob pressão, reconstrução patrimonial e mentalidade estratégica diante de perdas e viradas de vida. Qualquer aplicação prática dos conceitos descritos no livro é de inteira responsabilidade, risco e discernimento exclusivo do leitor.</p>

        <h2><span class="num">03.</span> Formatos Oficiais Disponíveis</h2>
        <p>A distribuição oficial é oferecida nos seguintes formatos:</p>
        <ul>
          <li><strong>Edição Física Oficial:</strong> Exemplar impresso com acabamento editorial de alto padrão (capa com orelhas, papel encorpado de alta gramatura e tipografia refinada), despachado para endereços válidos em todo o território nacional;</li>
          <li><strong>Edição Digital Direta:</strong> Arquivo digital oficial entregue mediante link protegido enviado ao e-mail cadastrado no ato da compra;</li>
          <li><strong>Edição Amazon Kindle:</strong> Distribuição digital realizada por meio da plataforma externa oficial da Amazon.com.br, sujeita às regras e aplicativo da Amazon.</li>
        </ul>

        <h2><span class="num">04.</span> Preços, Checkout e Pagamento</h2>
        <p>Os valores expressos no site são apresentados em Moeda Corrente Nacional (Reais - BRL) e podem contemplar promoções por tempo limitado. Os pagamentos são processados via infraestrutura oficial de WooCommerce com suporte a:</p>
        <ul>
          <li><strong>Pix:</strong> Confirmação e compensação instantânea com geração de QR Code dinâmico;</li>
          <li><strong>Cartão de Crédito:</strong> Processamento imediato com opção de parcelamento seguro;</li>
          <li><strong>Boleto Bancário:</strong> Sujeito a prazo de compensação bancária de até 72 horas úteis.</li>
        </ul>

        <h2><span class="num">05.</span> Envio, Prazos e Rastreamento Postal</h2>
        <p>Para os pedidos da <strong>Edição Física</strong>:</p>
        <ol>
          <li>O prazo estimado de entrega começa a fluir a partir da confirmação efetiva do pagamento pela instituição financeira;</li>
          <li>Os pedidos são expedidos via Correios do Brasil ou transportadora credenciada, com envio imediato de código de rastreamento por e-mail;</li>
          <li>O cliente é o único responsável pela exatidão das informações de endereço fornecidas durante o preenchimento do formulário de checkout. Inconsistências de endereço que resultem na devolução da encomenda poderão ensejar custos de reenvio.</li>
        </ol>

        <h2><span class="num">06.</span> Propriedade Intelectual e Direitos Autorais</h2>
        <p>Todo o conteúdo deste site, bem como os textos, diagramação, capa, ilustrações, marcas e materiais promocionais relativos à obra "O Pacto de 1 Bilhão" constituem propriedade intelectual exclusiva de <strong>Salih Abdulatif</strong>, protegidos pela <strong>Lei Federal de Direitos Autorais (Lei nº 9.610/1998)</strong> e tratados internacionais.</p>
        <div class="legal-highlight-box">
          <strong>Combate à Pirataria:</strong> É expressamente proibida a reprodução parcial ou integral, digitalização, cópia não autorizada, compartilhamento em grupos ou redes sociais, revenda clandestina ou rateio da obra digital ou física sem expressa autorização por escrito do autor. Infratores estão sujeitos a medidas judiciais cabíveis na esfera cível e criminal.
        </div>

        <h2><span class="num">07.</span> Modificações e Validade</h2>
        <p>Reservamo-nos o direito de aprimorar ou atualizar estes Termos e Condições a qualquer momento para adequação técnica, comercial ou legislativa. A utilização continuada dos serviços após tais modificações implicará anuência tácita aos novos termos vigentes.</p>

        <h2><span class="num">08.</span> Foro e Legislação Vigente</h2>
        <p>Estes Termos são regidos e interpretados em conformidade com as leis brasileiras. Fica eleito o Foro da Comarca do domicílio do consumidor para dirimir quaisquer dúvidas ou litígios decorrentes deste instrumento contratual.</p>

        <p style="font-size: 12px; color: rgba(54,67,74,0.7); margin-top: 25px;">Última revisão: Novembro de 2026. Todos os direitos reservados.</p>

      </article>
    </div>
  </main>

  <footer class="site-footer" id="rodape">
    <div class="shell-container site-footer__top">
      <div class="footer-brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-brand__link" aria-label="Voltar para a página inicial">
          <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="footer-brand__logo" width="175" height="76" loading="lazy">
        </a>
        <p>
          Registro editorial e reflexões de Salih Abdulatif.<br>
          Canais oficiais de atendimento e distribuição WooCommerce
        </p>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(home_url('/#inicio')); ?>">Início</a>
        <a href="<?php echo esc_url(home_url('/#livro')); ?>">Sobre a obra</a>
        <a href="<?php echo esc_url(home_url('/#autor')); ?>">O autor</a>
        <a href="<?php echo esc_url(home_url('/#compra')); ?>">Comprar Agora</a>
        <a href="<?php echo esc_url(home_url('/#faq')); ?>">Dúvidas frequentes</a>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('politica-de-privacidade')) ?: home_url('/politica-de-privacidade.html')); ?>">Política de Privacidade</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('termos-e-condicoes')) ?: home_url('/termos-e-condicoes.html')); ?>">Termos e Condições</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('trocas-e-devolucoes')) ?: home_url('/trocas-e-devolucoes.html')); ?>">Troca e Devoluções</a>
        <div class="footer-social" aria-label="Redes Sociais">
          <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="TikTok">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.89 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.52a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3 15.67 6.34 6.34 0 0 0 9.34 22a6.34 6.34 0 0 0 6.34-6.33V9.05c1.23.86 2.72 1.36 4.33 1.41V7.01a4.84 4.84 0 0 1-.42-.32z"/></svg>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="YouTube">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Instagram">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
          </a>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Facebook">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          </a>
        </div>
      </div>
    </div>
    <div class="shell-container site-footer__bottom">
      <span>© Copyright 2026 - Salih Abdulatif - Feito com ♥ Baita Site - <a title="Criação de Sites" href="https://www.baitasite.com.br/" target="_blank" rel="noopener">Criação de Site</a></span>
      <span>Aviso legal: O livro retrata a experiência pessoal do autor. Não constitui promessa de ganhos ou sucesso financeiro garantido.</span>
      <a href="#topo">Voltar ao topo ↑</a>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
