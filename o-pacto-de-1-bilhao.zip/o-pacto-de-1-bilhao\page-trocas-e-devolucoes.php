<?php
/**
 * Template Name: Página Legal - Troca e Devoluções
 * Description: Página institucional oficial de Troca, Devolução e Reembolso em conformidade com o CDC.
 */

if (!defined('ABSPATH')) {
    exit;
}

$template_uri = get_stylesheet_directory_uri();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5">
  <meta name="theme-color" content="#071520">
  <title>Troca e Devoluções — O Pacto de 1 Bilhão | Salih Abdulatif</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,700&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="<?php echo esc_url($template_uri . '/style.css?v=8.1'); ?>">
  <?php wp_head(); ?>
</head>
<body class="legal-page" id="topo">

  <header class="legal-header">
    <div class="shell-container legal-header__inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__brand" aria-label="O Pacto de 1 Bilhão - Início">
        <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="legal-header__logo" width="135" height="58" loading="eager">
      </a>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__back">
        <span>←</span> Voltar ao início
      </a>
    </div>
  </header>

  <section class="legal-hero">
    <div class="shell-container">
      <span class="section-index">DOCUMENTO OFICIAL • CÓDIGO DE DEFESA DO CONSUMIDOR</span>
      <h1>Troca e <em>Devoluções</em></h1>
      <p>Garantia incondicional de 7 dias, substituição rápida em caso de avaria editorial e total respeito ao leitor em conformidade com o CDC.</p>
    </div>
  </section>

  <main class="legal-main">
    <div class="shell-container">
      <article class="legal-card">
        
        <div class="legal-highlight-box">
          <strong>Garantia do Leitor (CDC Art. 49):</strong> Caso adquira a edição física e decida não ficar com o livro por qualquer motivo, você possui <strong>7 (sete) dias corridos a partir da data de entrega</strong> para solicitar a devolução e receber 100% do valor pago, com frete de devolução custeado por nossa equipe.
        </div>

        <h2><span class="num">01.</span> Princípios de Atendimento e Satisfação</h2>
        <p>A experiência com a obra <strong>"O Pacto de 1 Bilhão"</strong> foi pensada com rigor editorial e máxima seriedade comercial. Esta política estabelece de maneira transparente os direitos e procedimentos de troca, cancelamento e reembolso, em total conformidade com a <strong>Lei Federal nº 8.078/1990 (Código de Defesa do Consumidor — CDC)</strong>.</p>

        <h2><span class="num">02.</span> Direito de Arrependimento (Desistência em 7 Dias)</h2>
        <p>Em conformidade com o Artigo 49 do CDC, nas compras realizadas fora do estabelecimento comercial (pela internet):</p>
        <ul>
          <li>O leitor tem o direito de desistir da aquisição da <strong>Edição Física</strong> no prazo de até <strong>7 (sete) dias corridos</strong> contados a partir da data de recebimento do produto no endereço cadastrado;</li>
          <li>A solicitação deve ser formalizada dentro deste prazo através dos nossos canais oficiais de suporte;</li>
          <li>Forneceremos uma etiqueta de <strong>Logística Reversa dos Correios</strong> para que o exemplar seja postado em qualquer agência sem qualquer custo para você;</li>
          <li>Após a chegada do livro e verificação do seu estado físico, o estorno de 100% do valor pago (incluindo o frete original pago) será realizado de imediato.</li>
        </ul>

        <h2><span class="num">03.</span> Troca por Vício Gráfico ou Avaria no Transporte</h2>
        <p>Garantimos a qualidade impecável de cada exemplar expedido. Caso o livro chegue com qualquer imperfeição editorial (tais como páginas em branco, encadernação danificada, folhas invertidas ou danos visíveis decorrentes do transporte postal):</p>
        <ul>
          <li>Você poderá solicitar a substituição gratuita em até <strong>30 (trinta) dias corridos</strong> após o recebimento;</li>
          <li>Basta enviar uma foto ou breve vídeo demonstrando a avaria para o suporte;</li>
          <li>Providenciaremos imediatamente o despacho de um <strong>novo exemplar lacrado</strong>, com prioridade de postagem e sem qualquer custo adicional de reenvio.</li>
        </ul>

        <h2><span class="num">04.</span> Condições do Exemplar para Devolução</h2>
        <p>Para que a devolução por arrependimento seja homologada com sucesso:</p>
        <ol>
          <li>O exemplar do livro deve ser devolvido sem indícios de mau uso, manchas de líquidos, grifos à caneta ou rasgos provocados após o recebimento;</li>
          <li>Deve ser acondicionado na embalagem original ou em caixa protetora similar que preserve a integridade da obra durante o trânsito postal de retorno;</li>
          <li>Deve estar acompanhado da respectiva Nota Fiscal Eletrônica (DANFE) enviada no momento da compra.</li>
        </ol>

        <h2><span class="num">05.</span> Passo a Passo para Solicitar Troca ou Devolução</h2>
        <p>Para acionar o procedimento com máxima agilidade:</p>
        <ol>
          <li>Entre em contato com nossa equipe de suporte pelo e-mail ou WhatsApp oficial indicados no rodapé;</li>
          <li>Informe o <strong>número do seu pedido</strong> ou o <strong>CPF do titular da compra</strong>;</li>
          <li>Nossa equipe responderá com o código de autorização de postagem reversa dos Correios;</li>
          <li>Basta levar o livro embalado à agência dos Correios mais próxima e apresentar o código.</li>
        </ol>

        <h2><span class="num">06.</span> Prazos e Modalidades de Restituição Financeira</h2>
        <p>O reembolso será emitido no mesmo método de pagamento utilizado na aquisição:</p>
        <ul>
          <li><strong>Pagamentos via Pix:</strong> O estorno será transferido para a mesma conta bancária de origem em até <strong>2 (dois) a 5 (cinco) dias úteis</strong> após a recepção do produto na central de triagem;</li>
          <li><strong>Pagamentos via Cartão de Crédito:</strong> A solicitação de estorno é comunicada à administradora do cartão em até <strong>5 (cinco) dias úteis</strong>. O crédito do valor na fatura dependerá da data de fechamento da sua fatura e das políticas do banco emissor, ocorrendo normalmente na fatura atual ou na subsequente;</li>
          <li><strong>Pagamentos via Boleto Bancário:</strong> O valor será transferido via Pix ou TED para a conta bancária em nome do titular do pedido.</li>
        </ul>

        <h2><span class="num">07.</span> Edições Digitais e Compras Amazon Kindle</h2>
        <p>No caso das versões digitais:</p>
        <ul>
          <li>Para a <strong>Edição Digital Direta</strong> adquirida em nosso site, caso haja qualquer falha técnica no download ou na visualização do arquivo, nossa equipe prestará assistência técnica imediata ou providenciará nova via digital;</li>
          <li>Para compras direcionadas e finalizadas na plataforma <strong>Amazon Kindle</strong>, as diretrizes de cancelamento, devolução e estorno seguem integralmente as políticas comerciais e o suporte oficial da Amazon.com.br.</li>
        </ul>

        <h2><span class="num">08.</span> Canal Oficial de Atendimento</h2>
        <p>Dúvidas sobre o status do seu envio ou pedidos de troca e devolução? Nossa equipe está à disposição para atendê-lo com respeito e rapidez através dos canais de suporte no rodapé.</p>

        <p style="font-size: 12px; color: rgba(54,67,74,0.7); margin-top: 25px;">Última revisão: Novembro de 2026. Todos os direitos reservados.</p>

      </article>
    </div>
  </main>

  <footer class="site-footer" id="rodape">
    <div class="shell-container site-footer__top">
      <div class="footer-brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-brand__link" aria-label="Voltar para a página inicial">
          <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="footer-brand__logo" width="175" height="76" loading="lazy">
        </a>
        <p>
          Registro editorial e reflexões de Salih Abdulatif.<br>
          Canais oficiais de atendimento e distribuição WooCommerce
        </p>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(home_url('/#inicio')); ?>">Início</a>
        <a href="<?php echo esc_url(home_url('/#livro')); ?>">Sobre a obra</a>
        <a href="<?php echo esc_url(home_url('/#autor')); ?>">O autor</a>
        <a href="<?php echo esc_url(home_url('/#compra')); ?>">Comprar Agora</a>
        <a href="<?php echo esc_url(home_url('/#faq')); ?>">Dúvidas frequentes</a>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('politica-de-privacidade')) ?: home_url('/politica-de-privacidade.html')); ?>">Política de Privacidade</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('termos-e-condicoes')) ?: home_url('/termos-e-condicoes.html')); ?>">Termos e Condições</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('trocas-e-devolucoes')) ?: home_url('/trocas-e-devolucoes.html')); ?>">Troca e Devoluções</a>
        <div class="footer-social" aria-label="Redes Sociais">
          <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="TikTok">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.89 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.52a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3 15.67 6.34 6.34 0 0 0 9.34 22a6.34 6.34 0 0 0 6.34-6.33V9.05c1.23.86 2.72 1.36 4.33 1.41V7.01a4.84 4.84 0 0 1-.42-.32z"/></svg>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="YouTube">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Instagram">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
          </a>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Facebook">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          </a>
        </div>
      </div>
    </div>
    <div class="shell-container site-footer__bottom">
      <span>© Copyright 2026 - Salih Abdulatif - Feito com ♥ Baita Site - <a title="Criação de Sites" href="https://www.baitasite.com.br/" target="_blank" rel="noopener">Criação de Site</a></span>
      <span>Aviso legal: O livro retrata a experiência pessoal do autor. Não constitui promessa de ganhos ou sucesso financeiro garantido.</span>
      <a href="#topo">Voltar ao topo ↑</a>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
