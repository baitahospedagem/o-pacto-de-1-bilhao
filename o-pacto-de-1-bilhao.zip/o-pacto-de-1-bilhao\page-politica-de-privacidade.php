<?php
/**
 * Template Name: Página Legal - Política de Privacidade
 * Description: Página institucional oficial de Política de Privacidade em conformidade com a LGPD.
 */

if (!defined('ABSPATH')) {
    exit;
}

$template_uri = get_stylesheet_directory_uri();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5">
  <meta name="theme-color" content="#071520">
  <title>Política de Privacidade — O Pacto de 1 Bilhão | Salih Abdulatif</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,700&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="<?php echo esc_url($template_uri . '/style.css?v=8.1'); ?>">
  <?php wp_head(); ?>
</head>
<body class="legal-page" id="topo">

  <header class="legal-header">
    <div class="shell-container legal-header__inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__brand" aria-label="O Pacto de 1 Bilhão - Início">
        <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="legal-header__logo" width="135" height="58" loading="eager">
      </a>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="legal-header__back">
        <span>←</span> Voltar ao início
      </a>
    </div>
  </header>

  <section class="legal-hero">
    <div class="shell-container">
      <span class="section-index">DOCUMENTO OFICIAL • LGPD</span>
      <h1>Política de <em>Privacidade</em></h1>
      <p>Nosso compromisso inegociável com a transparência, privacidade e proteção dos seus dados pessoais em todas as etapas da sua experiência com a obra.</p>
    </div>
  </section>

  <main class="legal-main">
    <div class="shell-container">
      <article class="legal-card">
        
        <div class="legal-highlight-box">
          <strong>Resumo de Compromisso:</strong> Seus dados pessoais são coletados exclusivamente para viabilizar a entrega do livro físico, o acesso à edição digital, a emissão de nota fiscal e o suporte ao leitor. Não comercializamos, não alugamos e não compartilhamos suas informações com terceiros para fins publicitários externos.
        </div>

        <h2><span class="num">01.</span> Apresentação e Controlador</h2>
        <p>Esta Política de Privacidade estabelece as diretrizes de tratamento, coleta, uso e guarda de informações coletadas por meio deste site oficial da obra <strong>"O Pacto de 1 Bilhão"</strong>, de autoria de Salih Abdulatif.</p>
        <p>Ao navegar em nosso portal e adquirir qualquer formato da obra (edição física ou digital), você reconhece e concorda com as disposições aqui estabelecidas, em conformidade com a legislação brasileira vigente, em especial a <strong>Lei Geral de Proteção de Dados Pessoais (LGPD — Lei Federal nº 13.709/2018)</strong>.</p>

        <h2><span class="num">02.</span> Dados Pessoais Coletados</h2>
        <p>Coletamos apenas as informações estritamente necessárias para a conclusão e expedição do seu pedido:</p>
        <ul>
          <li><strong>Dados Cadastrais e de Identificação:</strong> Nome completo, número de CPF (obrigatório para emissão de Nota Fiscal Eletrônica e envio postal regulamentado) e data de nascimento (quando aplicável);</li>
          <li><strong>Dados de Contato:</strong> Endereço de e-mail (para confirmação de compra, envio de código de rastreio e entrega do exemplar digital) e número de telefone/WhatsApp (para avisos de status de entrega);</li>
          <li><strong>Dados de Entrega:</strong> Endereço completo com CEP, logradouro, número, complemento, bairro, cidade e estado, imprescindíveis para despacho pelos Correios ou transportadora parceira;</li>
          <li><strong>Dados de Pagamento:</strong> Processados em ambiente blindado e criptografado diretamente pelos provedores de pagamento homologados (WooCommerce Payments, gateways bancários e adquirentes). <strong>Não armazenamos dados sensíveis de cartão de crédito em nossos servidores locais.</strong></li>
        </ul>

        <h2><span class="num">03.</span> Finalidade e Base Legal do Tratamento</h2>
        <p>O tratamento de seus dados pessoais fundamenta-se nas seguintes bases legais dispostas no Artigo 7º da LGPD:</p>
        <ul>
          <li><strong>Execução de Contrato (Art. 7º, V):</strong> Para processamento do pedido de compra, autenticação do pagamento e entrega da obra física ou liberação do acesso digital;</li>
          <li><strong>Cumprimento de Obrigação Legal ou Regulatória (Art. 7º, II):</strong> Para emissão regular de Notas Fiscais Eletrônicas e guarda de registros exigidos pelo Fisco;</li>
          <li><strong>Legítimo Interesse e Suporte (Art. 7º, IX):</strong> Para prestar suporte e esclarecer dúvidas operacionais, sempre resguardando os direitos e liberdades individuais do titular.</li>
        </ul>

        <h2><span class="num">04.</span> Segurança e Criptografia das Informações</h2>
        <p>Adotamos medidas técnicas, administrativas e organizacionais de padrão bancário para assegurar a inviolabilidade dos seus dados:</p>
        <ul>
          <li>Certificado de Segurança SSL/TLS com criptografia de ponta a ponta de 256 bits em toda a navegação e no processo de checkout;</li>
          <li>Transações financeiras em conformidade rigorosa com o protocolo PCI-DSS (Payment Card Industry Data Security Standard);</li>
          <li>Acesso restrito a servidores e bancos de dados exclusivamente por operadores autorizados e submetidos a termos de sigilo e confidencialidade.</li>
        </ul>

        <h2><span class="num">05.</span> Compartilhamento de Dados</h2>
        <p>Seus dados são compartilhados unicamente com parceiros operacionais essenciais para a concretização do serviço:</p>
        <ul>
          <li><strong>Empresas de Logística e Entrega:</strong> Correios do Brasil e transportadoras privadas parceiras, exclusivamente com as informações de etiqueta de despacho (nome e endereço);</li>
          <li><strong>Intermediadores Financeiros:</strong> Gateways de pagamento responsáveis pela validação segura de Pix, boletos e cartões de crédito;</li>
          <li><strong>Autoridades Governamentais:</strong> Quando houver determinação judicial ou cumprimento estrito de obrigação fiscal e tributária.</li>
        </ul>

        <h2><span class="num">06.</span> Direitos do Titular de Dados</h2>
        <p>Nos termos do Artigo 18 da LGPD, você possui a qualquer momento o direito de solicitar gratuitamente:</p>
        <ol>
          <li>Confirmação da existência de tratamento de seus dados;</li>
          <li>Acesso completo aos dados pessoais mantidos em nossos registros;</li>
          <li>Correção de dados incompletos, inexatos ou desatualizados;</li>
          <li>Eliminação dos dados pessoais tratados mediante consentimento, exceto nas hipóteses de guarda obrigatória por lei fiscal;</li>
          <li>Informações sobre as entidades públicas e privadas com as quais realizamos uso compartilhado.</li>
        </ol>

        <h2><span class="num">07.</span> Cookies e Tecnologias de Navegação</h2>
        <p>Utilizamos cookies essenciais para manter a integridade da sua sessão de compra, lembrar itens adicionados ao carrinho e aprimorar a estabilidade técnica do site. Você tem a liberdade de desabilitar ou gerenciar cookies nas configurações de privacidade do seu navegador a qualquer instante.</p>

        <h2><span class="num">08.</span> Canal de Atendimento e DPO</h2>
        <p>Para exercer quaisquer de seus direitos de titular ou esclarecer qualquer dúvida sobre o tratamento de seus dados pessoais, entre em contato diretamente com nossa equipe oficial de atendimento através dos canais de suporte indicados no rodapé desta página.</p>

        <h2><span class="num">09.</span> Atualizações Desta Política</h2>
        <p>Esta Política de Privacidade poderá ser atualizada periodicamente para refletir aprimoramentos técnicos, novas funcionalidades ou eventuais alterações regulatórias. A versão em vigor estará sempre acessível neste endereço.</p>
        <p style="font-size: 12px; color: rgba(54,67,74,0.7); margin-top: 25px;">Última revisão: Novembro de 2026. Todos os direitos reservados.</p>

      </article>
    </div>
  </main>

  <footer class="site-footer" id="rodape">
    <div class="shell-container site-footer__top">
      <div class="footer-brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-brand__link" aria-label="Voltar para a página inicial">
          <img src="<?php echo esc_url($template_uri . '/logo_o_pacto_de_1_bilhao.png'); ?>" alt="O Pacto de 1 Bilhão" class="footer-brand__logo" width="175" height="76" loading="lazy">
        </a>
        <p>
          Registro editorial e reflexões de Salih Abdulatif.<br>
          Canais oficiais de atendimento e distribuição WooCommerce
        </p>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(home_url('/#inicio')); ?>">Início</a>
        <a href="<?php echo esc_url(home_url('/#livro')); ?>">Sobre a obra</a>
        <a href="<?php echo esc_url(home_url('/#autor')); ?>">O autor</a>
        <a href="<?php echo esc_url(home_url('/#compra')); ?>">Comprar Agora</a>
        <a href="<?php echo esc_url(home_url('/#faq')); ?>">Dúvidas frequentes</a>
      </div>
      <div class="footer-links">
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('politica-de-privacidade')) ?: home_url('/politica-de-privacidade.html')); ?>">Política de Privacidade</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('termos-e-condicoes')) ?: home_url('/termos-e-condicoes.html')); ?>">Termos e Condições</a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('trocas-e-devolucoes')) ?: home_url('/trocas-e-devolucoes.html')); ?>">Troca e Devoluções</a>
        <div class="footer-social" aria-label="Redes Sociais">
          <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="TikTok">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.89 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.52a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3 15.67 6.34 6.34 0 0 0 9.34 22a6.34 6.34 0 0 0 6.34-6.33V9.05c1.23.86 2.72 1.36 4.33 1.41V7.01a4.84 4.84 0 0 1-.42-.32z"/></svg>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="YouTube">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Instagram">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
          </a>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="footer-social__link" aria-label="Facebook">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          </a>
        </div>
      </div>
    </div>
    <div class="shell-container site-footer__bottom">
      <span>© Copyright 2026 - Salih Abdulatif - Feito com ♥ Baita Site - <a title="Criação de Sites" href="https://www.baitasite.com.br/" target="_blank" rel="noopener">Criação de Site</a></span>
      <span>Aviso legal: O livro retrata a experiência pessoal do autor. Não constitui promessa de ganhos ou sucesso financeiro garantido.</span>
      <a href="#topo">Voltar ao topo ↑</a>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
