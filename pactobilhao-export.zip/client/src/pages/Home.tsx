import { useEffect, useState } from "react";

type Edition = "physical" | "digital";

type FAQItem = {
  question: string;
  answer: string;
};

const heroAsset = "/hero_autor_livro.png";
const authorAsset = "/editorial_autor_livro.png";

const topics = [
  {
    number: "01",
    title: "[Tema ou aprendizado central do livro]",
    description: "[Descrição editável em duas linhas sobre o primeiro eixo da obra.]",
  },
  {
    number: "02",
    title: "[Tema ou aprendizado central do livro]",
    description: "[Descrição editável em duas linhas sobre o segundo eixo da obra.]",
  },
  {
    number: "03",
    title: "[Tema ou aprendizado central do livro]",
    description: "[Descrição editável em duas linhas sobre o terceiro eixo da obra.]",
  },
  {
    number: "04",
    title: "[Tema ou aprendizado central do livro]",
    description: "[Descrição editável em duas linhas sobre o quarto eixo da obra.]",
  },
  {
    number: "05",
    title: "[Tema ou aprendizado central do livro]",
    description: "[Descrição editável em duas linhas sobre o quinto eixo da obra.]",
  },
];

const faqs: FAQItem[] = [
  {
    question: "Qual é a diferença entre a edição física e a digital?",
    answer: "[Preencher com a diferença real entre as edições física e digital.]",
  },
  {
    question: "Como funciona o envio do livro físico?",
    answer: "[Preencher com prazo, regiões atendidas e condições reais de envio.]",
  },
  {
    question: "Como recebo a edição digital?",
    answer: "[Preencher com a informação real sobre acesso ou download.]",
  },
  {
    question: "Quais formas de pagamento estão disponíveis?",
    answer: "[Preencher com as formas de pagamento habilitadas no WooCommerce.]",
  },
  {
    question: "Posso comprar para presentear?",
    answer: "[Preencher com a informação real sobre compra para presente.]",
  },
  {
    question: "Como falar com o suporte?",
    answer: "[Preencher com o canal oficial e o horário real de atendimento.]",
  },
];

function track(event: string, payload: Record<string, string> = {}) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent("pacto:analytics", { detail: { event, ...payload } }));
  const dataLayer = (window as Window & { dataLayer?: unknown[] }).dataLayer;
  dataLayer?.push({ event, ...payload });
}

function scrollToPurchase(source: string) {
  track("cta_click", { source });
  document.getElementById("compra")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function LineIcon({ type }: { type: "perspective" | "revisit" | "formats" }) {
  if (type === "perspective") {
    return (
      <svg aria-hidden="true" viewBox="0 0 32 32" className="line-icon">
        <circle cx="16" cy="16" r="10" />
        <path d="M6 16h20M16 6c3 3 4.5 6.3 4.5 10S19 23 16 26M16 6c-3 3-4.5 6.3-4.5 10S13 23 16 26" />
      </svg>
    );
  }
  if (type === "revisit") {
    return (
      <svg aria-hidden="true" viewBox="0 0 32 32" className="line-icon">
        <path d="M8 8h16v17H8zM11 5h10M12 13h8M12 18h6" />
      </svg>
    );
  }
  return (
    <svg aria-hidden="true" viewBox="0 0 32 32" className="line-icon">
      <path d="M7 8h13v17H7zM12 8v17M12 11h13v17H12" />
    </svg>
  );
}

function AssetFrame({
  src,
  alt,
  kind,
}: {
  src: string;
  alt: string;
  kind: "hero" | "author";
}) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  return (
    <div className={`asset-frame asset-frame--${kind} ${loaded ? "is-loaded" : ""}`}>
      {!failed && (
        <img
          className="client-asset"
          src={src}
          alt={alt}
          loading={kind === "hero" ? "eager" : "lazy"}
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
        />
      )}
      {(!loaded || failed) && <EditorialFallback kind={kind} />}
    </div>
  );
}

function EditorialFallback({ kind }: { kind: "hero" | "author" }) {
  if (kind === "author") {
    return (
      <div className="author-fallback" aria-label="Área reservada para editorial_autor_livro.png">
        <div className="author-silhouette">
          <span className="author-head" />
          <span className="author-shoulder" />
        </div>
        <span className="fallback-caption">editorial_autor_livro.png</span>
      </div>
    );
  }

  return (
    <div className="hero-fallback" aria-label="Área reservada para hero_autor_livro.png">
      <div className="fallback-glow" />
      <div className="fallback-book">
        <span className="fallback-book-line" />
        <span className="fallback-book-kicker">UMA LEITURA SOBRE</span>
        <strong>O PACTO<br />DE 1 BILHÃO</strong>
        <span className="fallback-book-rule" />
        <span className="fallback-book-small">[capa do cliente]</span>
      </div>
      <span className="fallback-caption">hero_autor_livro.png</span>
    </div>
  );
}

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [dismissSticky, setDismissSticky] = useState(false);
  const [showSticky, setShowSticky] = useState(false);
  const [loadingEdition, setLoadingEdition] = useState<Edition | null>(null);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    track("hero_view");
    const revealTargets = document.querySelectorAll("[data-reveal]");
    if (typeof IntersectionObserver === "undefined") {
      revealTargets.forEach((element) => element.classList.add("is-visible"));
    }

    let revealObserver: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== "undefined") {
      revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              revealObserver?.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12 },
      );
      revealTargets.forEach((element) => revealObserver?.observe(element));
    }

    const onScroll = () => {
      setShowSticky(window.scrollY > window.innerHeight * 0.72);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    return () => {
      revealObserver?.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const handleEditionClick = (edition: Edition) => {
    setLoadingEdition(edition);
    track("edition_selected", { edition });
    window.setTimeout(() => {
      setLoadingEdition(null);
      setNotice(
        edition === "physical"
          ? "CTA preparado para conectar ao produto físico do WooCommerce."
          : "CTA preparado para conectar ao produto digital do WooCommerce.",
      );
      track("add_to_cart", { edition, status: "integration_ready" });
      track("begin_checkout", { edition, status: "integration_ready" });
      window.setTimeout(() => setNotice(""), 4200);
    }, 520);
  };

  return (
    <div className="site-shell">
      <div className="trust-bar">
        <div className="shell-container trust-bar__inner">
          <span className="trust-dot" />
          <span>Livro físico e digital</span>
          <span className="trust-divider" />
          <span>Compra segura pelo WooCommerce</span>
          <span className="trust-note">Conteúdo e condições editáveis</span>
        </div>
      </div>

      <header className="site-header shell-container" aria-label="Navegação principal">
        <a href="#inicio" className="wordmark" aria-label="O Pacto de 1 Bilhão — início">
          <span className="wordmark-mark">P/1B</span>
          <span className="wordmark-text">O Pacto de<br /><em>1 Bilhão</em></span>
        </a>
        <nav className="desktop-nav" aria-label="Navegação da página">
          <a href="#livro">O livro</a>
          <a href="#autor">O autor</a>
          <a href="#edicoes">Edições</a>
          <a href="#faq">Dúvidas</a>
        </nav>
        <button className="header-cta" onClick={() => scrollToPurchase("header")}>Escolher edição <span>↗</span></button>
      </header>

      <main>
        <section className="hero" id="inicio" data-section="hero">
          <div className="hero-ambient" />
          <div className="shell-container hero__grid">
            <div className="hero__copy">
              <p className="eyebrow hero-reveal hero-reveal--1"><span /> Um livro sobre visão, poder e transformação</p>
              <h1 className="hero-reveal hero-reveal--2"><span className="hero-title-line">O Pacto de</span><br /><em>1 Bilhão</em></h1>
              <p className="hero-subtitle hero-reveal hero-reveal--3">Uma leitura para quem quer ampliar a própria visão sobre dinheiro, poder e as grandes viradas da vida.</p>
              <p className="hero-support hero-reveal hero-reveal--4">Escolha a versão que combina com o seu momento: receba o livro físico ou comece agora com a edição digital.</p>
              <div className="hero-actions hero-reveal hero-reveal--5">
                <button className="button button--gold" onClick={() => scrollToPurchase("hero_primary")}>Quero garantir meu livro <span>↗</span></button>
                <a className="text-link" href="#livro" onClick={() => track("cta_click", { source: "hero_secondary" })}>Conhecer o livro <span>↓</span></a>
              </div>
              <div className="hero-meta hero-reveal hero-reveal--6">
                <span className="meta-lock">⌁</span>
                <span>Pagamento e entrega conforme a opção escolhida</span>
              </div>
            </div>
            <div className="hero__visual hero-reveal hero-reveal--visual">
              <div className="hero-visual-label">Edição<br /><strong>01 / 02</strong></div>
              <AssetFrame src={heroAsset} alt="Autor e livro O Pacto de 1 Bilhão" kind="hero" />
              <div className="hero-vertical-note">O PACTO DE 1 BILHÃO <span>•</span> UMA LEITURA MARCANTE</div>
            </div>
          </div>
          <a className="hero-scroll" href="#beneficios" aria-label="Descer para os benefícios"><span>Scroll para explorar</span><i /></a>
        </section>

        <section className="benefits" id="beneficios" data-section="benefits">
          <div className="shell-container benefits__grid">
            <div className="benefit-intro" data-reveal><span className="section-index">01 — EM POUCAS PALAVRAS</span><p>Uma obra para levar consigo<br />para além da primeira leitura.</p></div>
            <div className="benefit-item" data-reveal><LineIcon type="perspective" /><span>01</span><p>Uma leitura para ampliar sua perspectiva</p></div>
            <div className="benefit-item" data-reveal><LineIcon type="revisit" /><span>02</span><p>Conteúdo para revisitar e aplicar ao longo do tempo</p></div>
            <div className="benefit-item" data-reveal><LineIcon type="formats" /><span>03</span><p>Disponível em versão física e digital</p></div>
          </div>
        </section>

        <section className="section section--light why" id="livro" data-section="book-value">
          <div className="shell-container">
            <div className="section-heading section-heading--split" data-reveal>
              <div><span className="section-index">02 — POR QUE ESTE LIVRO?</span><h2>Uma pausa para<br /><em>mudar o enquadramento.</em></h2></div>
              <p>Mais do que um livro, esta é uma oportunidade de parar, observar o próprio caminho e rever as decisões que moldam uma grande virada. A obra convida o leitor a enxergar novas possibilidades com mais clareza, intenção e responsabilidade.</p>
            </div>
            <div className="why__body">
              <div className="book-still" data-reveal>
                <div className="book-still__shadow" />
                <div className="book-still__cover"><small>UMA OBRA SOBRE</small><strong>O PACTO<br />DE 1 BILHÃO</strong><i /> <span>[capa do cliente]</span></div>
                <span className="book-still__caption">Uma leitura para observar o caminho.<br />Uma capa que ainda receberá o asset do cliente.</span>
              </div>
              <div className="why-list" data-reveal>
                <p className="small-label">ESTA LEITURA PODE FAZER SENTIDO PARA</p>
                <div className="why-list__item"><b>01</b><p>Para quem busca uma nova perspectiva sobre crescimento e realização.</p></div>
                <div className="why-list__item"><b>02</b><p>Para quem valoriza histórias, aprendizados e decisões que deixam marca.</p></div>
                <div className="why-list__item"><b>03</b><p>Para quem quer uma leitura marcante para si ou para presentear.</p></div>
              </div>
            </div>
          </div>
        </section>

        <section className="section author" id="autor" data-section="author">
          <div className="shell-container author__grid">
            <div className="author__visual" data-reveal><AssetFrame src={authorAsset} alt="Retrato editorial do autor" kind="author" /><span className="author-index">03 / AUTOR</span></div>
            <div className="author__copy" data-reveal>
              <span className="section-index">03 — A HISTÓRIA POR TRÁS DA OBRA</span>
              <h2>A palavra ganha peso quando carrega uma <em>trajetória.</em></h2>
              <p className="author__lead">[Inserir aqui uma biografia curta e verdadeira do autor, destacando sua trajetória, experiência e o motivo pelo qual esta obra foi escrita.]</p>
              <div className="author__line" />
              <p className="author__caption">[Assinatura visual ou frase de autoria — inserir somente se fornecida.]</p>
            </div>
          </div>
        </section>

        <section className="section section--navy topics" id="temas" data-section="topics">
          <div className="shell-container">
            <div className="section-heading section-heading--topics" data-reveal><div><span className="section-index">04 — O QUE O LEITOR ENCONTRARÁ</span><h2>Uma jornada em<br /><em>cinco movimentos.</em></h2></div><p>Os capítulos abaixo são campos editáveis para receber os temas reais da obra. Sem atalhos, sem promessas prontas: apenas o espaço certo para o conteúdo do livro.</p></div>
            <div className="topic-list">
              {topics.map((topic) => <div className="topic-row" key={topic.number} data-reveal><span className="topic-number">{topic.number}</span><h3>{topic.title}</h3><p>{topic.description}</p><span className="topic-arrow">↗</span></div>)}
            </div>
          </div>
        </section>

        <section className="section editions" id="compra" data-section="purchase">
          <div className="shell-container">
            <div className="section-heading section-heading--purchase" data-reveal><div><span className="section-index">05 — ESCOLHA SUA EDIÇÃO</span><h2>Leve esta leitura<br /><em>para o seu próximo capítulo.</em></h2></div><p>Escolha a versão que combina com o seu momento. Os botões estão preparados para receber os produtos e variações reais do WooCommerce.</p></div>
            <div className="edition-grid" id="edicoes">
              <article className="edition-card" data-edition="physical" data-reveal>
                <div className="edition-card__top"><span className="edition-label">EDIÇÃO 01</span><span className="edition-format">FÍSICO</span></div>
                <div className="edition-card__visual"><div className="mini-book"><small>UMA OBRA SOBRE</small><strong>O PACTO<br />DE 1 BILHÃO</strong><i /></div><span className="mini-note">[imagem/capa do cliente]</span></div>
                <div className="edition-card__content"><h3>Livro físico</h3><p>[Descrição da edição física]</p><div className="edition-price">[R$ 00,00]</div><span className="edition-detail">Envio: [Prazo e condições reais]</span><button className="button button--dark" data-woocommerce-product="book-physical" data-product-id="[ID_PRODUTO_FISICO]" onClick={() => handleEditionClick("physical")} disabled={loadingEdition === "physical"}>{loadingEdition === "physical" ? "Preparando…" : "Comprar livro físico"}<span>↗</span></button></div>
              </article>
              <article className="edition-card edition-card--digital" data-edition="digital" data-reveal>
                <div className="edition-card__top"><span className="edition-label">EDIÇÃO 02</span><span className="edition-format">DIGITAL</span></div>
                <div className="edition-card__visual"><div className="digital-sheet"><span>PDF / EPUB</span><strong>O PACTO<br />DE 1 BILHÃO</strong><i /></div><span className="mini-note">[imagem/capa do cliente]</span></div>
                <div className="edition-card__content"><h3>Livro digital</h3><p>[Descrição da edição digital]</p><div className="edition-price">[R$ 00,00]</div><span className="edition-detail">Entrega: [Informação real sobre acesso/download]</span><button className="button button--dark" data-woocommerce-product="book-digital" data-product-id="[ID_PRODUTO_DIGITAL]" onClick={() => handleEditionClick("digital")} disabled={loadingEdition === "digital"}>{loadingEdition === "digital" ? "Preparando…" : "Comprar edição digital"}<span>↗</span></button></div>
              </article>
            </div>
            <p className="purchase-note"><span>◌</span> Nenhuma condição comercial foi presumida. Preços, disponibilidade e entrega devem ser preenchidos no WooCommerce.</p>
          </div>
        </section>

        <section className="section social-proof" data-section="social-proof">
          <div className="shell-container">
            <div className="social-proof__head" data-reveal><span className="section-index">06 — PROVA SOCIAL</span><h2>A experiência de quem<br /><em>já encontrou estas páginas.</em></h2><p>Área reservada para materiais autorizados pelo cliente. Depoimentos, fotos, imprensa ou números comprovados só devem entrar após aprovação.</p></div>
            <div className="quote-placeholders" data-reveal><div><span>01</span><p>[Depoimento real 1 — nome e contexto autorizados]</p></div><div><span>02</span><p>[Depoimento real 2 — nome e contexto autorizados]</p></div><div><span>03</span><p>[Depoimento real 3 — nome e contexto autorizados]</p></div></div>
          </div>
        </section>

        <section className="section faq" id="faq" data-section="faq">
          <div className="shell-container faq__grid">
            <div className="faq__intro" data-reveal><span className="section-index">07 — OBJEÇÕES E FAQ</span><h2>Antes de escolher,<br /><em>tire suas dúvidas.</em></h2><p>Respostas prontas para receber as informações oficiais da operação.</p><a href="#rodape">Falar com o suporte <span>↗</span></a></div>
            <div className="faq-list" data-reveal>
              {faqs.map((faq, index) => <div className={`faq-item ${openFaq === index ? "is-open" : ""}`} key={faq.question}><button id={`faq-button-${index}`} aria-expanded={openFaq === index} aria-controls={`faq-answer-${index}`} onClick={() => setOpenFaq(openFaq === index ? null : index)}><span>{faq.question}</span><i aria-hidden="true">{openFaq === index ? "−" : "+"}</i></button><div id={`faq-answer-${index}`} role="region" aria-labelledby={`faq-button-${index}`} aria-hidden={openFaq !== index} className="faq-answer"><p>{faq.answer}</p></div></div>)}
            </div>
          </div>
        </section>

        <section className="final-cta" data-section="final-cta">
          <div className="final-cta__orb" />
          <div className="shell-container final-cta__inner" data-reveal><div><span className="section-index">08 — UMA DECISÃO</span><h2>A próxima grande virada<br /><em>começa com uma decisão.</em></h2><p>Escolha sua edição e leve esta leitura para o seu próximo capítulo.</p><button className="button button--gold" onClick={() => scrollToPurchase("final_cta")}>Escolher minha edição <span>↗</span></button></div><div className="final-mini-book"><span>O PACTO<br /><b>DE 1 BILHÃO</b></span></div></div>
        </section>
      </main>

      <footer className="site-footer" id="rodape">
        <div className="shell-container site-footer__top"><a href="#inicio" className="wordmark wordmark--footer"><span className="wordmark-mark">P/1B</span><span className="wordmark-text">O Pacto de<br /><em>1 Bilhão</em></span></a><p>[Nome da marca ou editora]<br />[Informação oficial de contato]</p><div className="footer-links"><a href="#">Política de privacidade</a><a href="#">Termos de uso</a><a href="#">Canais oficiais</a></div></div>
        <div className="shell-container site-footer__bottom"><span>© 2026 [Marca/editora]. Todos os direitos reservados.</span><span>Informações de pagamento e avisos legais: [preencher dados reais]</span><a href="#inicio">Voltar ao topo ↑</a></div>
      </footer>

      {showSticky && !dismissSticky && <div className="sticky-cta" role="complementary"><button className="sticky-cta__close" aria-label="Fechar chamada fixa" onClick={() => setDismissSticky(true)}>×</button><div><span>O Pacto de 1 Bilhão</span><small>Escolha sua edição</small></div><button className="button button--gold" onClick={() => scrollToPurchase("sticky_mobile")}>Ver edições <span>↗</span></button></div>}
      {notice && <div className="cart-notice" role="status"><span>✓</span>{notice}</div>}
    </div>
  );
}
